===========================================================
  GoWA - WhatsApp Gateway & Automation Core (Windows x64)
  Versi: 1.1.4
===========================================================

CARA MENJALANKAN DI WINDOWS:
1. Ekstrak file zip ini ke folder pilihan Anda (misalnya C:\gowa).
2. Klik ganda file "run.bat" atau jalankan "run.ps1".
3. Browser akan otomatis membuka dashboard di http://localhost:8011.
4. Scan QR Code WhatsApp menggunakan kamera aplikasi WhatsApp Anda (Linked Devices).

PENGATURAN (.env):
- Port web default: 8011 (dapat diubah di file .env pada baris APP_PORT=8011).
- Database disimpan otomatis di folder "storages/whatsapp.db".
- AI Auto-Reply: Secara default DIMATIKAN total (AI_AUTO_REPLY_ENABLED=false) untuk keamanan.
  Jika ingin mengaktifkan AI, masukkan API Key Anda di file .env dan aktifkan melalui menu Analisis.

DOKUMENTASI LENGKAP & RILIS:
- https://github.com/dresar/gowanew
===========================================================
