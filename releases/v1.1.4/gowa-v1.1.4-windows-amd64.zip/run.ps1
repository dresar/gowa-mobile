Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "  GoWA - WhatsApp Gateway & Automation Core v1.1.4" -ForegroundColor Cyan
Write-Host "  Pure Go SQLite Edition (Standalone Windows x64)" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting GoWA service on http://localhost:8011 ..." -ForegroundColor Green
Start-Process "http://localhost:8011"
.\gowa.exe rest
