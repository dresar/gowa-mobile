===========================================================
  GoWA - WhatsApp Gateway & Automation Core (Windows x64)
  Versi: 1.1.6
===========================================================

CARA MENJALANKAN DI WINDOWS:
1. Ekstrak file zip ini ke folder pilihan Anda (misalnya C:\gowa).
2. Klik ganda file "run.bat" atau jalankan "run.ps1".
3. Browser akan otomatis membuka dashboard di http://localhost:8011.
4. Scan QR Code WhatsApp menggunakan kamera aplikasi WhatsApp Anda (Linked Devices).

FITUR & PEMBARUAN v1.1.6:
- Heads-up notification untuk pesan personal WhatsApp dengan suara dan getar.
- Tombol tes notifikasi interaktif di menu Pengaturan Umum.
- Pure Go SQLite Engine tanpa CGO (100% portable).
- Penyaringan anti-spam ketat untuk story/status dan broadcast.

DOKUMENTASI LENGKAP & RILIS:
- https://github.com/dresar/gowanew
===========================================================
