Write-Host '=======================================================' -ForegroundColor Green
Write-Host '  GoWA - WhatsApp Gateway & Automation Core v1.1.6' -ForegroundColor Green
Write-Host '  Pure Go SQLite Edition (Standalone Windows x64)' -ForegroundColor Green
Write-Host '=======================================================' -ForegroundColor Green
Write-Host ''
Write-Host 'Starting GoWA on http://localhost:8011 ...'
Start-Process 'http://localhost:8011'
.\gowa.exe rest
