@echo off
title GoWA - WhatsApp Gateway & Automation Core v1.1.6
color 0A
echo =======================================================
echo   GoWA - WhatsApp Gateway & Automation Core v1.1.6
echo   Pure Go SQLite Edition (Standalone Windows x64)
echo =======================================================
echo.
echo Starting GoWA service on http://localhost:8011 ...
echo Opening web dashboard in default browser...
start http://localhost:8011
echo.
gowa.exe rest
if errorlevel 1 (
    echo.
    echo [ERROR] GoWA stopped with error code %errorlevel%.
    pause
)
